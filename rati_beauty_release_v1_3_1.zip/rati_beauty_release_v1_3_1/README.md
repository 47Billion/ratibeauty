# rati_beauty
Landing page for Rati Beauty application.
