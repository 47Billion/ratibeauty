$(document).ready(function(){
    $('.slider-desk').slick({
        arrows: false,
        autoplay: true,
        autoplaySpeed: 4000
});
});